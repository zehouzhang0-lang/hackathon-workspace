---
name: douyin-video-creation
description: 抖音/短视频视频创作全流程支持——分镜脚本、拍摄清单、封面设计、BGM与音效、内容节奏结构、设备剪辑工具推荐。适用于用户要创作、规划或优化一条短视频时的拍摄、视觉、音频、结构、工具选择需求。
---

# 抖音视频创作

为短视频创作提供从"想法"到"可拍摄执行方案"的完整支持，覆盖拍摄脚本、视觉设计、音频配置、内容结构、创作工具五大方面，共 20 项功能。所有输出以可直接落地的方案/表格/话术形式给出。

## 功能地图

| 类别 | 功能 | 参考文件 |
|------|------|---------|
| 3.1 拍摄脚本 | 分镜脚本生成、拍摄清单、镜头语言、转场设计 | [references/shooting-script.md](references/shooting-script.md) |
| 3.2 视觉设计 | 封面设计建议、封面文字生成、封面模板库、视频滤镜推荐 | [references/visual-design.md](references/visual-design.md) |
| 3.3 音频配置 | BGM推荐、音效库、配音建议、音乐卡点 | [references/audio-config.md](references/audio-config.md) |
| 3.4 内容结构 | 黄金开头、内容节奏、结尾引导、时长建议 | [references/content-structure.md](references/content-structure.md) |
| 3.5 创作工具 | 拍摄设备推荐、剪辑软件推荐、素材资源库、创作SOP | [references/creation-tools.md](references/creation-tools.md) |

## 工作流程

1. **识别需求**：判断用户需要哪一类支持（脚本/视觉/音频/结构/工具）。
2. **收集关键信息**：视频主题、目标时长、内容类型（口播/教程/剧情/带货/知识科普）、行业、目标人群。缺省时用合理默认值（60秒、口播分享）并明确说明。
3. **生成方案**：按对应参考文件输出定制化方案。口播稿、分镜表格等结构化内容可直接用脚本生成。

## 生成脚本

需要生成口播稿、分镜脚本表格、完整视频脚本时，使用 `scripts/video_script.py` 中的 `VideoScriptGenerator`（移植自抖音运营大师）：

```bash
python scripts/video_script.py --theme "时间管理技巧" --duration 60 --type 口播分享
```

类方法：
- `generate_script(theme, duration, script_type)` — 完整脚本（开场+正文+结尾+BGM+拍摄要点）
- `generate_oral_script(theme, duration)` — 纯口播稿
- `generate_script_table(theme, duration)` — 分镜表格
- `generate_opening(opening_type, **kwargs)` / `generate_ending(ending_type, **kwargs)` — 黄金开头/结尾引导

`script_type` 支持：知识干货、口播分享、剧情反转、教程演示。`opening_type` 支持：痛点型、利益型、反差型、提问型、数字型。

## 通用原则（所有功能适用）

- **内容第一，形式第二**：设备、滤镜、转场都是为内容服务的，不要炫技。
- **具体化优于模糊化**：数字要具体（"3招"好过"几招"），承诺必须与视频内容一致。
- **自然优于夸张**：封面文字精简、引导话术自然、音乐卡点不硬卡。
- **版权意识**：素材/音乐确认版权，避免侵权。
- **执行优先**：新手分镜从简，先完成再优化。

## 交付格式

- 方案类：直接输出结构化文本（清单、表格、话术）。
- 脚本类：使用脚本生成器产出后，人工润色使其口语化、贴近用户主题。
- 所有输出用简体中文。
